/*===============================================================================
Copyright (c) 2017-2018 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

package com.vuforia.samples.GroundPlane.app.GroundPlane;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.AsyncTask;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;

import com.vuforia.Anchor;
import com.vuforia.AnchorResult;
import com.vuforia.Device;
import com.vuforia.DeviceTrackableResult;
import com.vuforia.HitTestResult;
import com.vuforia.Matrix34F;
import com.vuforia.Matrix44F;
import com.vuforia.PositionalDeviceTracker;
import com.vuforia.SmartTerrain;
import com.vuforia.State;
import com.vuforia.Tool;
import com.vuforia.Trackable;
import com.vuforia.TrackableResult;
import com.vuforia.TrackerManager;
import com.vuforia.Vec2F;
import com.vuforia.Vec3F;
import com.vuforia.Vuforia;
import com.vuforia.samples.SampleApplication.SampleAppRenderer;
import com.vuforia.samples.SampleApplication.SampleAppRendererControl;
import com.vuforia.samples.SampleApplication.SampleApplicationSession;
import com.vuforia.samples.SampleApplication.utils.LightingShaders;
import com.vuforia.samples.SampleApplication.utils.LoadingDialogHandler;
import com.vuforia.samples.SampleApplication.utils.Plane;
import com.vuforia.samples.SampleApplication.utils.SampleApplicationV3DModel;
import com.vuforia.samples.SampleApplication.utils.SampleMath;
import com.vuforia.samples.SampleApplication.utils.SampleUtils;
import com.vuforia.samples.SampleApplication.utils.Texture;

import java.io.IOException;
import java.util.Vector;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;


// The renderer class for the GroundPlane sample.
public class GroundPlaneRenderer implements GLSurfaceView.Renderer, SampleAppRendererControl
{
    private static final String LOGTAG = "GroundPlaneRenderer";

    private SampleApplicationSession vuforiaAppSession;
    private GroundPlane mActivity;
    private SampleAppRenderer mSampleAppRenderer;

    private Vector<Texture> mTextures;

    private int planeShaderProgramID;
    private int planeVertexHandle;
    private int planeTextureCoordHandle;
    private int planeMvpMatrixHandle;
    private int planeTexSampler2DHandle;
    private int planeColorHandle;

    private int shaderProgramID;
    private int vertexHandle;
    private int mvpMatrixHandle;
    private int mvMatrixHandle;
    private int normalHandle;
    private int textureCoordHandle;
    private int texSampler2DHandle;
    private int normalMatrixHandle;
    private int lightPositionHandle;
    private int lightColorHandle;

    private Plane mPlane;
    private SampleApplicationV3DModel mAstronaut, mDrone, mFurniture;

    private boolean mIsActive = false;

    private boolean mIsModelTranslating = false;
    private boolean mIsModelRotating = false;
    private boolean mModelsAreLoaded = false;
    boolean initializedModelShaders = false;

    static final int SAMPLE_APP_INTERACTIVE_MODE = 0;
    static final int SAMPLE_APP_MIDAIR_MODE = 1;
    static final int SAMPLE_APP_FURNITURE_MODE = 2;

    public static final int INSTRUCTION_POINT_TO_GROUND = 0;
    public static final int INSTRUCTION_TAP_TO_PLACE = 1;
    public static final int INSTRUCTION_GESTURES_INSTRUCTIONS = 2;
    public static final int INSTRUCTION_PRODUCT_PLACEMENT = 3;
    public static final int INSTRUCTION_UNDEFINED = 4;

    private static final int PRODUCT_PLACEMENT_STATE_TRANSLATING = 0;
    private static final int PRODUCT_PLACEMENT_STATE_IDLE = 1;

    private final int PLANE_2D_RETICLE_TEXTURE_INDEX = 2;
    private final int MIDAIR_RETICLE_TEXTURE_INDEX = 3;
    private final int PLANE_3D_RETICLE_TEXTURE_INDEX = 4;
    private final int SHADOW_TEXTURE_INDEX = 5;
    private final int TRANSLATE_TEXTURE_INDEX = 6;
    private final int ROTATE_TEXTURE_INDEX = 7;


    // Device and Smart Terrain poses
    private Matrix44F mDevicePoseMatrix;
    private Matrix44F mHitTestPoseMatrix;
    private Matrix44F mMidAirPoseMatrix;
    private Matrix44F mFurniturePoseMatrix;
    private Matrix44F mReticlePose;

    private Matrix44F modelViewMatrix, currentInverseProjMatrix;

    private Vec2F translateCoords;
    private Vec2F mLastTranslationCoords;

    // Anchor for registering content with latest hit test result
    private Anchor mHitTestAnchor, mMidAirAnchor, mFurnitureAnchor;
    private boolean mIsAnchorResultAvailable;
    private boolean mIsDeviceResultAvailable;
    private boolean mSetDroneNewPosition;
    private boolean mIsFurniturePlaced;
    private boolean mIsFurnitureBeingDragged;
    private boolean mRepositionFurniture;

    private int mProductPlacementState;
    float mProductScale;
    float mProductRotation;
    float mPreviousProductScale;
    float mNewProductRotation;

    private boolean mIsMidAirEnabled;

    int mCurrentMode;

    private boolean mPlaceAnchorContent = false;

    private final static String HIT_TEST_ANCHOR_NAME = "hitTestAnchor";
    private final static String MID_AIR_ANCHOR_NAME = "midAirAnchor";
    private final static String FURNITURE_ANCHOR_NAME = "furnitureAnchor";

    // Define a default, assumed device height above the plane where you'd like to place content.
    // The world coordinate system will be scaled accordingly to meet this device height value
    // once you create the first successful anchor from a HitTestResult. If your users are adults
    // to place something on the floor use appx. 1.4m. For a tabletop experience use appx. 0.5m.
    // In apps targeted for kids reduce the assumptions to ~80% of these values.
    private final static float DEFAULT_HEIGHT_ABOVE_GROUND = 1.4f;  // In meters

    public GroundPlaneRenderer(GroundPlane activity, SampleApplicationSession session)
    {
        mActivity = activity;
        vuforiaAppSession = session;
        // SampleAppRenderer used to encapsulate the use of RenderingPrimitives setting
        // the device mode AR/VR and stereo mode
        mSampleAppRenderer = new SampleAppRenderer(this, mActivity, Device.MODE.MODE_AR, vuforiaAppSession.getVideoMode(), false, 0.1f, 10f);
    }

    // Called to draw the current frame.
    @Override
    public void onDrawFrame(GL10 gl)
    {
        if (!mIsActive || !mModelsAreLoaded)
        {
            return;
        }

        // Call our function to render content from SampleAppRenderer class
        mSampleAppRenderer.render();
    }


    public void setActive(boolean active)
    {
        mIsActive = active;

        if (mIsActive)
        {
            mSampleAppRenderer.configureVideoBackground();
        }
    }


    // Called when the surface is created or recreated.
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config)
    {
        Log.d(LOGTAG, "GLRenderer.onSurfaceCreated");

        // Call Vuforia function to (re)initialize rendering after first use
        // or after OpenGL ES context was lost (e.g. after onPause/onResume):
        vuforiaAppSession.onSurfaceCreated();

        mSampleAppRenderer.onSurfaceCreated();
    }


    // Called when the surface changed size.
    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height)
    {
        Log.d(LOGTAG, "GLRenderer.onSurfaceChanged");

        // Call Vuforia function to handle render surface size changes:
        vuforiaAppSession.onSurfaceChanged(width, height);

        // RenderingPrimitives to be updated when some rendering change is done
        mSampleAppRenderer.onConfigurationChanged(mIsActive);

        initRendering();
    }


    // Function for initializing the renderer.
    private void initRendering()
    {
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, Vuforia.requiresAlpha() ? 0.0f
                : 1.0f);

        mActivity.setInstructionsState(INSTRUCTION_UNDEFINED);

        for (Texture t : mTextures)
        {
            GLES20.glGenTextures(1, t.mTextureID, 0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t.mTextureID[0]);
            GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT);

            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, t.mWidth, t.mHeight, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, t.mData);
        }

        planeShaderProgramID = SampleUtils.createProgramFromShaderSrc(
                TextureColorShaders.TEXTURE_COLOR_VERTEX_SHADER,
                TextureColorShaders.TEXTURE_COLOR_FRAGMENT_SHADER);

        mPlane = new Plane();

        if (planeShaderProgramID > 0)
        {
            planeVertexHandle = GLES20.glGetAttribLocation(planeShaderProgramID,
                    "vertexPosition");
            planeTextureCoordHandle = GLES20.glGetAttribLocation(planeShaderProgramID,
                    "vertexTexCoord");
            planeMvpMatrixHandle = GLES20.glGetUniformLocation(planeShaderProgramID,
                    "modelViewProjectionMatrix");
            planeTexSampler2DHandle = GLES20.glGetUniformLocation(planeShaderProgramID,
                    "texSampler2D");
            planeColorHandle = GLES20.glGetUniformLocation(planeShaderProgramID,
                    "uniformColor");

        }
        else
        {
            Log.e(LOGTAG, "Could not init plane shader");
        }

        shaderProgramID = SampleUtils.createProgramFromShaderSrc(
                LightingShaders.LIGHTING_VERTEX_SHADER,
                LightingShaders.LIGHTING_FRAGMENT_SHADER);

        if (shaderProgramID > 0)
        {
            vertexHandle = GLES20.glGetAttribLocation(shaderProgramID, "vertexPosition");
            normalHandle = GLES20.glGetAttribLocation(shaderProgramID, "vertexNormal");
            textureCoordHandle = GLES20.glGetAttribLocation(shaderProgramID, "vertexTexCoord");
            mvpMatrixHandle = GLES20.glGetUniformLocation(shaderProgramID, "u_mvpMatrix");
            mvMatrixHandle = GLES20.glGetUniformLocation(shaderProgramID, "u_mvMatrix");
            normalMatrixHandle = GLES20.glGetUniformLocation(shaderProgramID, "u_normalMatrix");
            lightPositionHandle = GLES20.glGetUniformLocation(shaderProgramID, "u_lightPos");
            lightColorHandle = GLES20.glGetUniformLocation(shaderProgramID, "u_lightColor");
            texSampler2DHandle = GLES20.glGetUniformLocation(shaderProgramID, "texSampler2D");

        }
        else
        {
            Log.e(LOGTAG, "Could not init lighting shader");
        }

        if (!mModelsAreLoaded)
        {
            LoadModelTask astronautModelTask = new LoadModelTask();
            astronautModelTask.execute("astronaut.v3d");

            LoadModelTask droneModelTask = new LoadModelTask();
            droneModelTask.execute("drone.v3d");

            LoadModelTask chairModelTask = new LoadModelTask();
            chairModelTask.execute("chair.v3d");
        }

        mDevicePoseMatrix = SampleMath.Matrix44FIdentity();
        mMidAirPoseMatrix = SampleMath.Matrix44FIdentity();
        mHitTestPoseMatrix = SampleMath.Matrix44FIdentity();
        mFurniturePoseMatrix = SampleMath.Matrix44FIdentity();
        mReticlePose = SampleMath.Matrix44FIdentity();

        translateCoords = new Vec2F();
        mLastTranslationCoords = new Vec2F();

        mIsAnchorResultAvailable = false;
        mIsDeviceResultAvailable = false;
        mSetDroneNewPosition = false;
        mIsMidAirEnabled = false;
        mIsFurniturePlaced = false;
        mIsFurnitureBeingDragged = false;
        mRepositionFurniture = false;

        mProductPlacementState = PRODUCT_PLACEMENT_STATE_IDLE;
        mProductRotation = 0;
        mNewProductRotation = 0;
        mProductScale = 0.5f;
        mPreviousProductScale = 0.5f;

        mActivity.setMidAirEnabled(false);
    }

    private class LoadModelTask extends AsyncTask<String, Integer, Boolean>
    {
        protected Boolean doInBackground(String... params)
        {
            boolean isModelLoaded = false;

            if (params[0].equals("astronaut.v3d"))
            {
                mAstronaut = new SampleApplicationV3DModel();

                try
                {
                    mAstronaut.loadModel(mActivity.getResources().getAssets(), params[0]);
                    isModelLoaded = true;
                } catch (IOException e)
                {
                    Log.e(LOGTAG, "Unable to load model");
                }
            }
            else if (params[0].equals("drone.v3d"))
            {
                mDrone = new SampleApplicationV3DModel();

                try
                {

                    mDrone.loadModel(mActivity.getResources().getAssets(), params[0]);
                    isModelLoaded = true;
                } catch (IOException e)
                {
                    Log.e(LOGTAG, "Unable to load model");
                }
            }
            else if (params[0].equals("chair.v3d"))
            {
                mFurniture = new SampleApplicationV3DModel();

                try
                {

                    mFurniture.loadModel(mActivity.getResources().getAssets(), params[0]);
                    mFurniture.setTransparency(.5f);
                    isModelLoaded = true;
                } catch (IOException e)
                {
                    Log.e(LOGTAG, "Unable to load model");
                }
            }

            return isModelLoaded;
        }

        protected void onPostExecute(Boolean result)
        {
            // Hide the Loading Dialog
            mActivity.loadingDialogHandler
                    .sendEmptyMessage(LoadingDialogHandler.HIDE_LOADING_DIALOG);
            mActivity.mGroundPlaneLayout.setVisibility(View.VISIBLE);
            mModelsAreLoaded = mFurniture != null && mDrone != null && mAstronaut != null &&
                    mFurniture.isLoaded() && mDrone.isLoaded() && mAstronaut.isLoaded();
        }
    }

    public void updateConfiguration()
    {
        mSampleAppRenderer.onConfigurationChanged(mIsActive);
    }

    // The render function called from SampleAppRendering by using RenderingPrimitives views.
    // The state is owned by SampleAppRenderer which is controlling it's lifecycle.
    // State should not be cached outside this method.
    public void renderFrame(State state, float[] projectionMatrix, Matrix44F vbProjectionMatrix)
    {
        boolean render3DReticle = false;
        boolean renderAstronaut = false;
        boolean renderDrone = false;
        boolean renderFurniture = false;

        if (!initializedModelShaders)
        {
            mFurniture.initShaders();
            initializedModelShaders = true;
        }

        // Renders video background replacing Renderer.DrawVideoBackground()
        mSampleAppRenderer.renderVideoBackground();

        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        // handle face culling, we need to detect if we are using reflection
        // to determine the direction of the culling
        GLES20.glEnable(GLES20.GL_CULL_FACE);
        GLES20.glCullFace(GLES20.GL_BACK);

        if (state.getNumTrackableResults() == 0)
        {
            Log.i(LOGTAG, "No trackables");
        }
        else
        {
            Matrix34F devicePoseTemp = new Matrix34F();
            boolean furnitureAnchorExists = false;

            // Did we find any trackables this frame?
            for (int tIdx = 0; tIdx < state.getNumTrackableResults(); tIdx++)
            {
                TrackableResult result = state.getTrackableResult(tIdx);

                modelViewMatrix = Tool.convertPose2GLMatrix(result.getPose());

                Matrix44F projMatrix = new Matrix44F();
                projMatrix.setData(projectionMatrix);
                currentInverseProjMatrix = SampleMath.Matrix44FInverse(new Matrix44F(projMatrix));

                if (result.isOfType(DeviceTrackableResult.getClassType()))
                {
                    devicePoseTemp.setData(result.getPose().getData());
                    mDevicePoseMatrix = SampleMath.Matrix44FTranspose(SampleMath.Matrix44FInverse(modelViewMatrix));
                    mIsDeviceResultAvailable = true;
                }
                else if (result.isOfType(AnchorResult.getClassType()))
                {
                    if (!mIsMidAirEnabled)
                    {
                        mIsMidAirEnabled = true;
                        mActivity.setMidAirEnabled(mIsMidAirEnabled);
                    }

                    mIsAnchorResultAvailable = true;

                    if (result.getTrackable().getName().equals(HIT_TEST_ANCHOR_NAME))
                    {
                        renderAstronaut = true;
                        mHitTestPoseMatrix = modelViewMatrix;
                    }

                    if (result.getTrackable().getName().equals(MID_AIR_ANCHOR_NAME))
                    {
                        renderDrone = true;
                        mMidAirPoseMatrix = modelViewMatrix;
                    }

                    if (result.getTrackable().getName().equals(FURNITURE_ANCHOR_NAME))
                    {
                        furnitureAnchorExists = true;

                        if(!mRepositionFurniture)
                        {
                            renderFurniture = true;
                        }

                        mIsFurniturePlaced = true;

                        if (mIsModelTranslating)
                        {
                            updateFurnitureMatrix(state, translateCoords);
                        }
                        else
                        {
                            mFurniturePoseMatrix = modelViewMatrix;
                        }

                    }
                }
            }

            if(!furnitureAnchorExists)
            {
                mIsFurniturePlaced = false;
            }

            if (mPlaceAnchorContent)
            {
                if (mCurrentMode == SAMPLE_APP_INTERACTIVE_MODE
                        || mCurrentMode == SAMPLE_APP_FURNITURE_MODE)
                {
                    if(!isModelTranslating())
                    {
                        if(mRepositionFurniture)
                        {
                            performHitTest(state, mLastTranslationCoords.getData()[0], mLastTranslationCoords.getData()[1], DEFAULT_HEIGHT_ABOVE_GROUND, true);
                            mRepositionFurniture = false;
                        }
                        else
                        {
                            performHitTest(state, 0.5f, 0.5f, DEFAULT_HEIGHT_ABOVE_GROUND, true);
                        }

                    }
                }
                else
                {
                    mSetDroneNewPosition = true;
                }

                mPlaceAnchorContent = false;
            }

            // Should we set a new position for the drone?
            if (mSetDroneNewPosition)
            {
                Matrix34F midAirPose = new Matrix34F();
                midAirPose.setData(devicePoseTemp.getData());

                // Matrix to translate drone at a given distance in front of camera
                Matrix34F translationMat = new Matrix34F();
                float[] translationArray = new float[12];
                translationArray[0] = 1;
                translationArray[5] = 1;
                translationArray[10] = 1;

                translationMat.setData(translationArray);
                Tool.setTranslation(translationMat, new Vec3F(0f, 0f, -3f));

                midAirPose = Tool.multiply(midAirPose, translationMat);

                // Create an anchor for the drone
                createMidAirAnchor(midAirPose);
                mSetDroneNewPosition = false;
            }

            // To render a placement-reticle we need to perform a hit test to get an intersection point
            // with ground plane. Until an anchor from HitTestResult is created successfully the device
            // is assumed to be at deviceHeight along gravity vector above the plane.
            if (!mIsAnchorResultAvailable || mCurrentMode == SAMPLE_APP_INTERACTIVE_MODE
                    || mCurrentMode == SAMPLE_APP_FURNITURE_MODE)
            {
                // Perform a hit test on the center of screen
                if(!(renderFurniture && mCurrentMode == SAMPLE_APP_FURNITURE_MODE))
                    render3DReticle = performHitTest(state, 0.5f, 0.5f, DEFAULT_HEIGHT_ABOVE_GROUND, false);
            }

            boolean shouldPointToGround = (!render3DReticle && mCurrentMode == SAMPLE_APP_INTERACTIVE_MODE) ||
                        (!renderFurniture && !render3DReticle && mCurrentMode == SAMPLE_APP_FURNITURE_MODE);

            if(shouldPointToGround)
            {
                mActivity.setInstructionsState(INSTRUCTION_POINT_TO_GROUND);
            }
            else if(mCurrentMode == SAMPLE_APP_FURNITURE_MODE && renderFurniture)
            {
                if(mProductPlacementState == PRODUCT_PLACEMENT_STATE_IDLE)
                {
                    mActivity.setInstructionsState(INSTRUCTION_GESTURES_INSTRUCTIONS);
                }
                else
                {
                    mActivity.setInstructionsState(INSTRUCTION_PRODUCT_PLACEMENT);
                }
            }
            else
            {
                mActivity.setInstructionsState(INSTRUCTION_TAP_TO_PLACE);
            }


            // If we have a device and anchor results we translate and scale the models so they are positioned at the center of the reticle
            // For the drone we want to align it also vertically since it is in mid-air
            if (mIsDeviceResultAvailable && mIsAnchorResultAvailable)
            {
                if (renderFurniture)
                {
                    float[] chairMV = mFurniturePoseMatrix.getData();
                    float[] chairMVP = new float[16];

                    Matrix.translateM(chairMV, 0, 0f, 0f, 0);
                    Matrix.rotateM(chairMV, 0, mProductRotation + mNewProductRotation, 0.0f, 1.0f, 0.0f);
                    Matrix.scaleM(chairMV, 0, mProductScale, mProductScale, mProductScale);

                    Matrix.multiplyMM(chairMV, 0, mDevicePoseMatrix.getData(), 0, chairMV, 0);
                    Matrix.multiplyMM(chairMVP, 0, projectionMatrix, 0, chairMV, 0);

                    float shadowScale = mProductScale * 1.0f;
                    float gesturesScale = mProductScale * 2.0f;
                    float[] shadowMV = mFurniturePoseMatrix.getData();
                    float[] gesturesMV = mFurniturePoseMatrix.getData();

                    Matrix.rotateM(shadowMV, 0, -90, 1.0f, 0.0f, 0.0f);
                    Matrix.scaleM(shadowMV, 0, shadowScale, shadowScale, shadowScale);
                    Matrix.rotateM(gesturesMV, 0, -90, 1.0f, 0.0f, 0.0f);
                    Matrix.scaleM(gesturesMV, 0, gesturesScale, gesturesScale, gesturesScale);

                    GLES20.glDisable(GLES20.GL_DEPTH_TEST);

                    Matrix44F projMatrix = new Matrix44F();
                    projMatrix.setData(projectionMatrix);
                    Matrix44F shadowMVMatrix = new Matrix44F();
                    shadowMVMatrix.setData(shadowMV);
                    Matrix44F gesturesMVMatrix = new Matrix44F();
                    gesturesMVMatrix.setData(gesturesMV);

                    renderPlaneTexturedWithProjectionMatrix(projMatrix, shadowMVMatrix, mTextures.get(SHADOW_TEXTURE_INDEX).mTextureID[0], true, false);

                    if(mProductPlacementState != PRODUCT_PLACEMENT_STATE_IDLE)
                    {
                        int gestureTexture = isModelRotating() ? ROTATE_TEXTURE_INDEX : TRANSLATE_TEXTURE_INDEX;
                        renderPlaneTexturedWithProjectionMatrix(projMatrix, gesturesMVMatrix, mTextures.get(gestureTexture).mTextureID[0], false, false);
                    }

                    GLES20.glEnable(GLES20.GL_DEPTH_TEST);

                    mFurniture.render(chairMV, chairMVP);
                }

                if (renderAstronaut)
                {
                    float[] astronautMV = mHitTestPoseMatrix.getData();
                    Matrix.translateM(astronautMV, 0, -0.30f, 0, 0);
                    Matrix.scaleM(astronautMV, 0, 10f, 10f, 10f);

                    renderModelV3D(mAstronaut, astronautMV,
                            projectionMatrix, SAMPLE_APP_INTERACTIVE_MODE);
                }

                if (renderDrone)
                {
                    float[] droneMV = mMidAirPoseMatrix.getData();
                    Matrix.translateM(droneMV, 0, -0.75f, -0.375f, 0);
                    Matrix.scaleM(droneMV, 0, 10f, 10f, 10f);
                    renderModelV3D(mDrone, droneMV,
                            projectionMatrix, SAMPLE_APP_MIDAIR_MODE);
                }

            }
        }

        // Rendering reticle
        if ((!render3DReticle || !mIsAnchorResultAvailable) && !(renderFurniture && mCurrentMode == SAMPLE_APP_FURNITURE_MODE))
        {
            render2DReticle();
        }
        else if (mCurrentMode == SAMPLE_APP_INTERACTIVE_MODE)
        {
            Matrix44F projMatrix = new Matrix44F();
            projMatrix.setData(projectionMatrix);
            renderReticleWithProjectionMatrix(projMatrix, false);
        }
        else if(mCurrentMode == SAMPLE_APP_FURNITURE_MODE && !mIsFurniturePlaced)
        {
            float furnitureMVPMatrix[] = mReticlePose.getData();
            float furnitureMV[] = mReticlePose.getData();
            Matrix.scaleM(furnitureMV, 0, mProductScale, mProductScale, mProductScale);
            float poseMatrix[] =  new float[16];;
            Matrix.multiplyMM(poseMatrix, 0, mDevicePoseMatrix.getData(), 0, furnitureMV, 0);

            Matrix.multiplyMM(furnitureMVPMatrix, 0, projectionMatrix, 0, poseMatrix, 0);

            float shadowMV[] = mReticlePose.getData();
            float shadowScale = mProductScale * 1.0f;

            Matrix.rotateM(shadowMV, 0, -90, 1.0f, 0.0f, 0);
            Matrix.scaleM(shadowMV, 0 , shadowScale, shadowScale, shadowScale);

            Matrix44F shadowMVMatrix = new Matrix44F();
            shadowMVMatrix.setData(shadowMV);

            Matrix44F projMatrix = new Matrix44F();
            projMatrix.setData(projectionMatrix);

            // Disable depth test so the shadow does not occlude the furniture
            GLES20.glDisable(GLES20.GL_DEPTH_TEST);
            renderPlaneTexturedWithProjectionMatrix(projMatrix, shadowMVMatrix, mTextures.get(SHADOW_TEXTURE_INDEX).mTextureID[0], true, false);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);

            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
            GLES20.glBlendEquation(GLES20.GL_FUNC_ADD);
            mFurniture.render(furnitureMV, furnitureMVPMatrix);

        }

        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_CULL_FACE);

    }


    private void render2DReticle()
    {
        // Calculate aspect ratio
        DisplayMetrics metrics = new DisplayMetrics();
        mActivity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        float aspectRatio = (float) metrics.widthPixels / (float) metrics.heightPixels;

        // Create orthographic matrix
        float[] reticleProj = SampleMath.Matrix44FIdentity().getData();

        float orthoScale = 1.25f;
        Matrix.orthoM(reticleProj, 0, aspectRatio * -orthoScale, aspectRatio * orthoScale, -orthoScale, orthoScale, 1f, -1f);

        Matrix44F reticleProjection = new Matrix44F();
        reticleProjection.setData(reticleProj);

        mReticlePose = SampleMath.Matrix44FIdentity();

        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        renderReticleWithProjectionMatrix(reticleProjection, true);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
    }


    private void renderReticleWithProjectionMatrix(Matrix44F projectionMatrix, boolean isReticle2D)
    {
        int textureIndex = (mCurrentMode == SAMPLE_APP_INTERACTIVE_MODE || mCurrentMode == SAMPLE_APP_FURNITURE_MODE)
                ? PLANE_2D_RETICLE_TEXTURE_INDEX : MIDAIR_RETICLE_TEXTURE_INDEX;

        if (mCurrentMode == SAMPLE_APP_INTERACTIVE_MODE && !isReticle2D)
        {
            textureIndex = PLANE_3D_RETICLE_TEXTURE_INDEX;
        }

        Matrix44F reticleMV = new Matrix44F();
        reticleMV.setData(mReticlePose.getData());

        // We rotate the reticle for it sit on the plane where we intend to render the reticle instead of intersecting it
        float[] reticleTransform = reticleMV.getData();
        Matrix.rotateM(reticleTransform, 0, 90, -1, 0, 0);

        reticleMV.setData(reticleTransform);

        renderPlaneTexturedWithProjectionMatrix(projectionMatrix, reticleMV, mTextures.get(textureIndex).mTextureID[0], false, isReticle2D);
    }

    private void renderPlaneTexturedWithProjectionMatrix(Matrix44F projectionMatrix, Matrix44F modelViewMatrix, int textureHandle, boolean isSubstractingColors, boolean isRender2D)
    {
        float[] modelViewProjectionMatrix = projectionMatrix.getData();
        float[] poseMatrix = SampleMath.Matrix44FIdentity().getData();

        if (!isRender2D)
        {
            Matrix.multiplyMM(poseMatrix, 0, mDevicePoseMatrix.getData(), 0, modelViewMatrix.getData(), 0);
        }

        Matrix.multiplyMM(modelViewProjectionMatrix, 0, projectionMatrix.getData(), 0, poseMatrix, 0);

        GLES20.glEnable(GLES20.GL_BLEND);
        if(!isSubstractingColors)
        {
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
            GLES20.glBlendEquation(GLES20.GL_FUNC_ADD);
        }
        else
        {
            GLES20.glBlendFuncSeparate(GLES20.GL_SRC_ALPHA, GLES20.GL_DST_ALPHA, GLES20.GL_SRC_ALPHA, GLES20.GL_DST_ALPHA);
            GLES20.glBlendEquationSeparate(GLES20.GL_FUNC_REVERSE_SUBTRACT, GLES20.GL_FUNC_ADD);
        }

        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureHandle);

        GLES20.glEnableVertexAttribArray(planeVertexHandle);
        GLES20.glVertexAttribPointer(planeVertexHandle, 3, GLES20.GL_FLOAT, false, 0, mPlane.getVertices());

        GLES20.glEnableVertexAttribArray(planeTextureCoordHandle);
        GLES20.glVertexAttribPointer(planeTextureCoordHandle, 2, GLES20.GL_FLOAT, false, 0, mPlane.getTexCoords());

        GLES20.glUseProgram(planeShaderProgramID);
        GLES20.glUniformMatrix4fv(planeMvpMatrixHandle, 1, false, modelViewProjectionMatrix, 0);
        GLES20.glUniform4f(planeColorHandle, 1, 1, 1, 1);
        GLES20.glUniform1i(planeTexSampler2DHandle, 0);

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, Plane.NUM_PLANE_INDEX, GLES20.GL_UNSIGNED_SHORT, mPlane.getIndices());

        GLES20.glDisableVertexAttribArray(planeTextureCoordHandle);
        GLES20.glDisableVertexAttribArray(planeVertexHandle);
        GLES20.glUseProgram(0);

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);

        GLES20.glBlendFuncSeparate(GLES20.GL_SRC_ALPHA, GLES20.GL_DST_ALPHA, GLES20.GL_SRC_ALPHA, GLES20.GL_DST_ALPHA);
        GLES20.glBlendEquationSeparate(GLES20.GL_FUNC_ADD, GLES20.GL_FUNC_ADD);
        GLES20.glDisable(GLES20.GL_BLEND);

        SampleUtils.checkGLError("renderPlaneTextured");
    }


    private void renderModelV3D(SampleApplicationV3DModel model,
                                float[] modelPoseMatrix, float[] projectionMatrix, int mode)
    {
        float[] modelViewProjection = new float[16];
        float[] poseMatrix = new float[16];

        Matrix.setIdentityM(poseMatrix, 0);

        Matrix.multiplyMM(poseMatrix, 0, mDevicePoseMatrix.getData(), 0, modelPoseMatrix, 0);
        Matrix.multiplyMM(modelViewProjection, 0, projectionMatrix, 0, poseMatrix, 0);

        GLES20.glUseProgram(shaderProgramID);

        GLES20.glVertexAttribPointer(vertexHandle, 3, GLES20.GL_FLOAT, false, 0, model.getVertices());
        GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, 0, model.getNormals());
        GLES20.glVertexAttribPointer(textureCoordHandle, 2, GLES20.GL_FLOAT, false, 0, model.getTexCoords());

        GLES20.glEnableVertexAttribArray(vertexHandle);
        GLES20.glEnableVertexAttribArray(normalHandle);
        GLES20.glEnableVertexAttribArray(textureCoordHandle);

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mTextures.elementAt(mode).mTextureID[0]);

        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, modelViewProjection, 0);
        GLES20.glUniformMatrix4fv(mvMatrixHandle, 1, false, poseMatrix, 0);

        float[] inverseMatrix = new float[16];
        Matrix.invertM(inverseMatrix, 0, poseMatrix, 0);

        float[] normalMatrix = new float[16];
        Matrix.transposeM(normalMatrix, 0, inverseMatrix, 0);

        GLES20.glUniformMatrix4fv(normalMatrixHandle, 1, false, normalMatrix, 0);

        GLES20.glUniform4f(lightPositionHandle, 0.2f, -1.0f, 0.5f, -1.0f);
        GLES20.glUniform4f(lightColorHandle, 0.5f, 0.5f, 0.5f, 1.0f);

        GLES20.glUniform1i(texSampler2DHandle, 0);

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, model.getNumObjectVertex());

        GLES20.glDisableVertexAttribArray(vertexHandle);
        GLES20.glDisableVertexAttribArray(normalHandle);
        GLES20.glDisableVertexAttribArray(textureCoordHandle);

        SampleUtils.checkGLError("Render Model V3D");
    }

    public void handleTap()
    {
        if (!(mCurrentMode == SAMPLE_APP_FURNITURE_MODE && mIsFurniturePlaced))
        {
            mPlaceAnchorContent = true;
        }
    }

    private boolean performHitTest(State state, float normalTouchPointX, float normalTouchPointY,
                                   float deviceHeightInMeters, boolean createAnchor)
    {
        Log.i(LOGTAG, "Perform hit test with normalized touch point ("
                + normalTouchPointX + ", " + normalTouchPointY + ")");

        TrackerManager trackerManager = TrackerManager.getInstance();
        PositionalDeviceTracker deviceTracker = (PositionalDeviceTracker) trackerManager.getTracker(PositionalDeviceTracker.getClassType());
        SmartTerrain smartTerrain = (SmartTerrain) trackerManager.getTracker(SmartTerrain.getClassType());

        if (deviceTracker == null || smartTerrain == null)
        {
            Log.e(LOGTAG, "Failed to perform hit test, trackers not initialized");
            return false;
        }

        Vec2F hitTestPoint = new Vec2F(normalTouchPointX, normalTouchPointY);
        int hitTestHint = SmartTerrain.HITTEST_HINT.HITTEST_HINT_NONE; // hit test hint is currently unused

        // A hit test is performed for a given State at normalized screen coordinates.
        // The deviceHeight is an developer provided assumption as explained on
        // definition of DEFAULT_HEIGHT_ABOVE_GROUND.
        smartTerrain.hitTest(state, hitTestPoint, deviceHeightInMeters, hitTestHint);

        if (smartTerrain.getHitTestResultCount() > 0)
        {
            // Use first HitTestResult
            final HitTestResult hitTestResult = smartTerrain.getHitTestResult(0);

            if (createAnchor)
            {
                createSurfaceAnchor(hitTestResult);
            }

            mReticlePose = Tool.convertPose2GLMatrix(hitTestResult.getPose());
            mIsAnchorResultAvailable = true;
            return true;
        }
        else
        {
            Log.i(LOGTAG, "Hit test returned no results");
            return false;
        }
    }


    private void createSurfaceAnchor(HitTestResult hitTestResult)
    {
        TrackerManager trackerManager = TrackerManager.getInstance();
        PositionalDeviceTracker deviceTracker = (PositionalDeviceTracker) trackerManager.getTracker(PositionalDeviceTracker.getClassType());

        if (mCurrentMode == SAMPLE_APP_INTERACTIVE_MODE)
        {
            // Destroy previous hit test anchor if needed
            if (mHitTestAnchor != null)
            {
                Log.i(LOGTAG, "Destroying hit test anchor with name " + HIT_TEST_ANCHOR_NAME);
                boolean result = deviceTracker.destroyAnchor(mHitTestAnchor);
                Log.i(LOGTAG, "Hit test anchor " + (result ? "successfully destroyed" : "failed to destroy"));
            }

            mHitTestAnchor = deviceTracker.createAnchor(HIT_TEST_ANCHOR_NAME, hitTestResult);

            if (mHitTestAnchor != null)
            {
                Log.i(LOGTAG, "Successfully created hit test anchor with name " + mHitTestAnchor.getName());
            }
            else
            {
                Log.e(LOGTAG, "Failed to create hit test anchor");
            }
        }
        else if (mCurrentMode == SAMPLE_APP_FURNITURE_MODE)
        {
            // Destroy previous hit test anchor if needed
            if (mFurnitureAnchor != null)
            {
                Log.i(LOGTAG, "Destroying hit test anchor with name " + FURNITURE_ANCHOR_NAME);
                boolean result = deviceTracker.destroyAnchor(mFurnitureAnchor);
                Log.i(LOGTAG, "Hit test anchor " + (result ? "successfully destroyed" : "failed to destroy"));
            }

            mFurnitureAnchor = deviceTracker.createAnchor(FURNITURE_ANCHOR_NAME, hitTestResult);

            if (mFurnitureAnchor != null)
            {
                Log.i(LOGTAG, "Successfully created hit test anchor with name " + mFurnitureAnchor.getName());
                mFurniture.setTransparency(1.0f);
                mActivity.setInstructionsState(PRODUCT_PLACEMENT_STATE_IDLE);
            }
            else
            {
                Log.e(LOGTAG, "Failed to create hit test anchor");
            }
        }
    }


    private void createMidAirAnchor(Matrix34F anchorPoseMatrix)
    {
        Log.i(LOGTAG, "Create Mid Air Anchor");

        TrackerManager trackerManager = TrackerManager.getInstance();
        PositionalDeviceTracker deviceTracker = (PositionalDeviceTracker)
                trackerManager.getTracker(PositionalDeviceTracker.getClassType());

        if (mMidAirAnchor != null)
        {
            Log.i(LOGTAG, "Destroying hit test anchor with name " + MID_AIR_ANCHOR_NAME);
            boolean result = deviceTracker.destroyAnchor(mMidAirAnchor);
            Log.i(LOGTAG, "Hit test anchor " + (result ? "successfully destroyed" : "failed to destroy"));
        }

        mMidAirAnchor = deviceTracker.createAnchor(MID_AIR_ANCHOR_NAME, anchorPoseMatrix);

        if (mMidAirAnchor != null)
        {
            Log.i(LOGTAG, "Successfully created hit test anchor with name " + mMidAirAnchor.getName());
        }
        else
        {
            Log.e(LOGTAG, "Failed to create mid air anchor");
        }
    }


    private boolean updateFurnitureMatrix(State state, Vec2F screenCoords)
    {
        TrackerManager trackerManager = TrackerManager.getInstance();
        PositionalDeviceTracker deviceTracker = (PositionalDeviceTracker) trackerManager.getTracker(PositionalDeviceTracker.getClassType());
        SmartTerrain smartTerrain = (SmartTerrain) trackerManager.getTracker(SmartTerrain.getClassType());

        if (deviceTracker == null || smartTerrain == null)
        {
            Log.e(LOGTAG, "Failed to perform hit test, trackers not initialized");
            return false;
        }

        Vec2F hitTestPoint = new Vec2F(screenCoords.getData()[0], screenCoords.getData()[1]);
        int hitTestHint = SmartTerrain.HITTEST_HINT.HITTEST_HINT_NONE; // hit test hint is currently unused
        mLastTranslationCoords.setData(screenCoords.getData());

        // A hit test is performed for a given State at normalized screen coordinates.
        // The deviceHeight is an developer provided assumption as explained on
        // definition of DEFAULT_HEIGHT_ABOVE_GROUND.
        smartTerrain.hitTest(state, hitTestPoint, DEFAULT_HEIGHT_ABOVE_GROUND, hitTestHint);

        if (smartTerrain.getHitTestResultCount() > 0)
        {
            // Use first HitTestResult
            final HitTestResult hitTestResult = smartTerrain.getHitTestResult(0);
            mFurniturePoseMatrix = Tool.convertPose2GLMatrix(hitTestResult.getPose());

            return true;
        }
        else
        {
            Log.i(LOGTAG, "Hit test returned no results");
            return false;
        }
    }


    public void resetGroundPlane()
    {
        mDevicePoseMatrix = SampleMath.Matrix44FIdentity();
        mMidAirPoseMatrix = SampleMath.Matrix44FIdentity();
        mHitTestPoseMatrix = SampleMath.Matrix44FIdentity();
        mFurniturePoseMatrix = SampleMath.Matrix44FIdentity();
        mReticlePose = SampleMath.Matrix44FIdentity();

        mIsAnchorResultAvailable = false;
        mIsDeviceResultAvailable = false;
        mSetDroneNewPosition = false;
        mIsFurniturePlaced = false;
        mRepositionFurniture = false;

        mHitTestAnchor = null;
        mMidAirAnchor = null;
        mFurnitureAnchor = null;

        mFurniture.setTransparency(0.5f);

        resetTrackers();

        setMode(SAMPLE_APP_FURNITURE_MODE);
    }


    private void resetTrackers()
    {
        TrackerManager trackerManager = TrackerManager.getInstance();
        PositionalDeviceTracker deviceTracker = (PositionalDeviceTracker) trackerManager.
                getTracker(PositionalDeviceTracker.getClassType());
        SmartTerrain smartTerrain = (SmartTerrain) trackerManager.getTracker(SmartTerrain.getClassType());

        if (deviceTracker == null || smartTerrain == null)
        {
            Log.e(LOGTAG, "Failed to reset trackers, trackers not initialized");
            return;
        }

        // Anchor not valid anymore after stop() call, anchor poses should be discarded
        if (mHitTestAnchor != null)
        {
            deviceTracker.destroyAnchor(mHitTestAnchor);
            mHitTestAnchor = null;
        }

        if (mMidAirAnchor != null)
        {
            deviceTracker.destroyAnchor(mMidAirAnchor);
            mMidAirAnchor = null;
        }

        if (mFurnitureAnchor != null)
        {
            deviceTracker.destroyAnchor(mFurnitureAnchor);
            mFurnitureAnchor = null;
        }

        deviceTracker.stop();
        smartTerrain.stop();

        deviceTracker.start();
        smartTerrain.start();
    }


    private void printUserData(Trackable trackable)
    {
        //String userData = (String) trackable.getUserData();
        //Log.d(LOGTAG, "UserData:Retreived User Data	\"" + userData + "\"");
    }


    public void setTextures(Vector<Texture> textures)
    {
        mTextures = textures;
    }


    public void setMode(int mode)
    {
        if (mode >= SAMPLE_APP_INTERACTIVE_MODE
                && mode <= SAMPLE_APP_FURNITURE_MODE)
        {
            mCurrentMode = mode;
        }
        else
        {
            Log.e(LOGTAG, "Invalid mode: " + mode);
        }

        // Set UI
        mActivity.setModeUI(mode);
    }

    public boolean isModelRotating()
    {
        return mIsModelRotating;
    }

    public void setModelRotating(boolean modelRotating)
    {
        mIsModelRotating = modelRotating;

        mProductPlacementState = modelRotating ? PRODUCT_PLACEMENT_STATE_TRANSLATING : PRODUCT_PLACEMENT_STATE_IDLE;
        mActivity.setInstructionsState(mProductPlacementState);

        if(!modelRotating)
        {
            mProductRotation += mNewProductRotation;
            if(mProductRotation < 0)
                mProductRotation += 360;
            mProductRotation %= 360;
        }

        mNewProductRotation = 0;
    }

    public void setCurrentRotation(float angle)
    {
        mNewProductRotation = angle;
    }

    public boolean isModelTranslating()
    {
        return mIsModelTranslating;
    }

    public Anchor getFurnitureAnchor()
    {
        return mFurnitureAnchor;
    }

    public void setModelTranslating(boolean modelTranslating)
    {
        mIsModelTranslating = modelTranslating;

        mProductPlacementState = modelTranslating ? PRODUCT_PLACEMENT_STATE_TRANSLATING : PRODUCT_PLACEMENT_STATE_IDLE;
        mActivity.setInstructionsState(mProductPlacementState);

        if (!mIsModelTranslating)
        {
            mPlaceAnchorContent = true;
            mRepositionFurniture = true;
        }
    }

    public void setTranslateCoordinates(Vec2F coords)
    {
        DisplayMetrics metrics = new DisplayMetrics();
        mActivity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        float normalizedX = coords.getData()[0] / metrics.widthPixels;
        float normalizedY = coords.getData()[1] / metrics.heightPixels;

        float[] normalizedCoords = {normalizedX, normalizedY};

        translateCoords.setData(normalizedCoords);
    }
}
