/*===============================================================================
Copyright (c) 2018 PTC Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

package com.vuforia.samples.SampleApplication.utils;

import android.view.MotionEvent;


public class SampleGestureListener
{

    TouchEvent touchEvent;

    TouchEvent firstTouch;
    TouchEvent secondTouch;

    float mLastTouchX, mLastTouchY;
    int mActivePointerId = -1;
    int mSecondActivePointerId = -1;

    private boolean mIsRotating = false;
    private float mAngle = 0;

    public static final int ACTION_INVALID = -1;
    public static final int ACTION_DOWN = 0;
    public static final int ACTION_MOVE = 1;
    public static final int ACTION_UP = 2;
    public static final int ACTION_CANCEL = 3;

    public static final int GESTURE_TAP = 0;
    public static final int GESTURE_DRAG = 1;
    public static final int GESTURE_ROTATE = 2;

    // Used to delay translation for it not to start as soon as a touch is detected
    private static final float START_TRANSLATING_THRESHOLD = 30.0f;


    private static final String LOGTAG = "SampleGestureListener";

    public SampleGestureListener()
    {
        touchEvent = new TouchEvent();
        firstTouch = new TouchEvent();
        secondTouch = new TouchEvent();
    }

    public int onTouchEvent(MotionEvent ev)
    {

        final int action = ev.getActionMasked();

        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                final int pointerIndex = ev.getActionIndex();
                final float x = ev.getX(pointerIndex);
                final float y = ev.getY(pointerIndex);

                // Remember where we started (for dragging)
                mLastTouchX = x;
                mLastTouchY = y;
                // Save the ID of this pointer (for dragging)
                mActivePointerId = ev.getPointerId(pointerIndex);
                firstTouch.setStartX(x);
                firstTouch.setStartY(y);

                break;
            }

            case MotionEvent.ACTION_POINTER_DOWN:
            {
                if(ev.findPointerIndex(mActivePointerId) != -1)
                {
                    firstTouch.setStartX(ev.getX(ev.findPointerIndex(mActivePointerId)));
                    firstTouch.setStartY(ev.getY(ev.findPointerIndex(mActivePointerId)));
                }
                else
                {
                    mActivePointerId = ACTION_INVALID;
                }

                mSecondActivePointerId = ev.getPointerId(ev.getActionIndex());
                secondTouch.setStartX(ev.getX(ev.findPointerIndex(mSecondActivePointerId)));
                secondTouch.setStartY(ev.getY(ev.findPointerIndex(mSecondActivePointerId)));
            }

            case MotionEvent.ACTION_MOVE: {
                if(mActivePointerId == ACTION_INVALID)
                {
                    break;
                }

                // Find the index of the active pointer and fetch its position
                final int pointerIndex = ev.findPointerIndex(mActivePointerId);

                final float x = ev.getX(pointerIndex);
                final float y = ev.getY(pointerIndex);

                firstTouch.setX(x);
                firstTouch.setY(y);

                // Calculate the distance moved
                final float dx = x - mLastTouchX;
                final float dy = y - mLastTouchY;

                // Remember this touch position for the next move event
                mLastTouchX = x;
                mLastTouchY = y;

                firstTouch.setLastX(x);
                firstTouch.setLastY(y);
                if(mSecondActivePointerId != ACTION_INVALID)
                {
                    final int secondPointerIndex = ev.findPointerIndex(mSecondActivePointerId);

                    if(secondPointerIndex != -1)
                    {
                        secondTouch.setLastX(ev.getX(secondPointerIndex));
                        secondTouch.setLastY(ev.getY(secondPointerIndex));

                        mAngle = twoLinesAngle(firstTouch.getStartX(), firstTouch.getStartY(),
                                firstTouch.getLastX(), firstTouch.getLastY(),
                                secondTouch.getStartX(), secondTouch.getStartY(),
                                secondTouch.getLastX(), secondTouch.getLastY());

                        mIsRotating = true;
                    }
                }
                break;
            }

            case MotionEvent.ACTION_UP: {
                mActivePointerId = ACTION_INVALID;
                mSecondActivePointerId = ACTION_INVALID;
                mIsRotating = false;
                break;
            }

            case MotionEvent.ACTION_CANCEL: {
                mActivePointerId = ACTION_INVALID;
                mSecondActivePointerId = ACTION_INVALID;
                mIsRotating = false;
                break;
            }

            case MotionEvent.ACTION_POINTER_UP: {
                mActivePointerId = ACTION_INVALID;
                mSecondActivePointerId = ACTION_INVALID;
                mIsRotating = false;
                break;
            }
        }

        return action;
    }

    public boolean isRotating()
    {
        return mIsRotating;
    }

    public float getRotationAngle()
    {
        return mAngle;
    }

    private float twoLinesAngle (float firstTouchX, float firstTouchY, float firstTouchLastX, float firstTouchLastY,
                                 float secondTouchX, float secondTouchY, float secondTouchLastX, float secondTouchLastY)
    {
        float firstTouchAngle = (float) Math.atan2( (firstTouchY - secondTouchY), (firstTouchX - secondTouchX) );
        float secondTouchAngle = (float) Math.atan2( (firstTouchLastY - secondTouchLastY), (firstTouchLastX - secondTouchLastX) );

        float angle = ((float)Math.toDegrees(firstTouchAngle - secondTouchAngle) * 3.0f) % 360; // 3.0f to increase 3x gesture sensibility

        if (angle < 0)
        {
            angle += 360.0f;
        }

        if (angle >= 360.0f)
        {
            angle -= 360.0f;
        }

        return angle;
    }

    public boolean isFirstTouchInsideThreshold()
    {
        float dx = firstTouch.getLastX() - firstTouch.getStartX();
        float dy = firstTouch.getLastY() - firstTouch.getStartY();
        dx = dx < 0 ? -dx : dx;
        dy = dy < 0 ? -dy : dy;

        boolean isTouchMotionInsideThreshold = dx < START_TRANSLATING_THRESHOLD && dy < START_TRANSLATING_THRESHOLD;

        return isTouchMotionInsideThreshold;
    }

    public TouchEvent getFirstTouch()
    {
        return firstTouch;
    }

}
