/*===============================================================================
Copyright (c) 2015-2017 PTC Inc. All Rights Reserved.

Copyright (c) 2012-2014 Qualcomm Connected Experiences, Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other 
countries.
===============================================================================*/

package com.vuforia.samples.OcclusionManagement.app.OcclusionManagement;

import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Vector;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.util.DisplayMetrics;
import android.util.Log;

import com.vuforia.Device;
import com.vuforia.Matrix44F;
import com.vuforia.MultiTargetResult;
import com.vuforia.Renderer;
import com.vuforia.State;
import com.vuforia.Tool;
import com.vuforia.TrackableResult;
import com.vuforia.Vec4I;
import com.vuforia.VideoBackgroundConfig;
import com.vuforia.VideoBackgroundTextureInfo;
import com.vuforia.Vuforia;
import com.vuforia.samples.SampleApplication.SampleApplicationSession;
import com.vuforia.samples.SampleApplication.SampleAppRenderer;
import com.vuforia.samples.SampleApplication.SampleAppRendererControl;
import com.vuforia.samples.SampleApplication.utils.CubeObject;
import com.vuforia.samples.SampleApplication.utils.CubeShaders;
import com.vuforia.samples.SampleApplication.utils.SampleUtils;
import com.vuforia.samples.SampleApplication.utils.Teapot;
import com.vuforia.samples.SampleApplication.utils.Texture;


// The renderer class for the OcclusionManagement sample.
public class OcclusionManagementRenderer implements GLSurfaceView.Renderer, SampleAppRendererControl
{
    private static final String LOGTAG = "OcclusionMgmtRenderer";
    
    SampleApplicationSession vuforiaAppSession;
    SampleAppRenderer mSampleAppRenderer;

    private OcclusionManagement mActivity;
    private boolean mIsActive = false;
    
    private Vector<Texture> mTextures;
    
    private int shaderProgramID = 0;
    private int vertexHandle = 0;
    private int normalHandle = 0;
    private int textureCoordHandle = 0;
    private int mvpMatrixHandle = 0;
    
    // These values will hold the GL viewport
    int viewportPosition_x = 0;
    int viewportPosition_y = 0;
    int viewportSize_x = 0;
    int viewportSize_y = 0;
    
    double vbOrthoQuadVerticesArray[] = { -1.0f, -1.0f, 0.0f, 1.0f, -1.0f,
            0.0f, 1.0f, 1.0f, 0.0f, -1.0f, 1.0f, 0.0f };
    
    double vbOrthoQuadTexCoordsArray[] = { 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,
            0.0f, 0.0f };
    
    short vbOrthoQuadIndicesArray[] = { 0, 1, 2, 2, 3, 0 };
    
    Buffer vbOrthoQuadVertices, vbOrthoQuadTexCoords, vbOrthoQuadIndices;
    
    private CubeObject cubeObject = new CubeObject();
    private Teapot teapot = new Teapot();

    private int vbShaderProgramOcclusionID = 0;
    private int vbVertexPositionOcclusionHandle = 0;
    private int vbVertexTexCoordOcclusionHandle = 0;
    private int vbTexSamplerVideoOcclusionHandle = 0;
    private int vbProjectionMatrixOcclusionHandle = 0;
    private int vbTexSamplerMaskOcclusionHandle = 0;
    private int vbViewportOriginHandle = 0;
    private int vbViewportSizeHandle = 0;
    private int vbTextureRatioHandle = 0;

    // Constants:
    final static float kCubeScaleX = 0.12f * 0.75f / 2.0f;
    final static float kCubeScaleY = 0.12f * 1.00f / 2.0f;
    final static float kCubeScaleZ = 0.12f * 0.50f / 2.0f;
    
    final static float kTeapotScaleX = 0.12f * 0.015f;
    final static float kTeapotScaleY = 0.12f * 0.015f;
    final static float kTeapotScaleZ = 0.12f * 0.015f;
    
    
    public OcclusionManagementRenderer(OcclusionManagement activity,
        SampleApplicationSession session)
    {
        mActivity = activity;
        vuforiaAppSession = session;

        // SampleAppRenderer used to encapsulate the use of RenderingPrimitives setting
        // the device mode AR/VR and stereo mode
        mSampleAppRenderer = new SampleAppRenderer(this, mActivity, Device.MODE.MODE_AR, false, 0.01f, 5f);
    }
    
    
    // Called when the surface is created or recreated.
    public void onSurfaceCreated(GL10 gl, EGLConfig config)
    {
        Log.d(LOGTAG, "GLRenderer.onSurfaceCreated");
        
        // Call function to initialize rendering:
        initRendering();
        
        // Call Vuforia function to (re)initialize rendering after first use
        // or after OpenGL ES context was lost (e.g. after onPause/onResume):
        Vuforia.onSurfaceCreated();

        mSampleAppRenderer.onSurfaceCreated();

    }
    
    
    // Called when the surface changed size.
    public void onSurfaceChanged(GL10 gl, int width, int height)
    {
        Log.d(LOGTAG, "GLRenderer.onSurfaceChanged");
        
        // Call Vuforia function to handle render surface size changes:
        Vuforia.onSurfaceChanged(width, height);
        
        setViewport();

        // RenderingPrimitives to be updated when some rendering change is done
        mSampleAppRenderer.onConfigurationChanged(mIsActive);

        // Call function to initialize rendering:
        initRendering();
    }
    
    
    // Called to draw the current frame.
    public void onDrawFrame(GL10 gl)
    {
        if (!mIsActive)
            return;

        // Call our function to render content from SampleAppRenderer class
        mSampleAppRenderer.render();
    }


    public void setActive(boolean active)
    {
        mIsActive = active;

        if(mIsActive)
            mSampleAppRenderer.configureVideoBackground();
    }

    
    void initRendering()
    {
        Log.d(LOGTAG, "OcclusionManagementRenderer.initRendering");
        
        // Define clear color
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, Vuforia.requiresAlpha() ? 0.0f
            : 1.0f);
        
        // Now generate the OpenGL texture objects and add settings
        for (Texture t : mTextures)
        {
            GLES20.glGenTextures(1, t.mTextureID, 0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t.mTextureID[0]);
            GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA,
                t.mWidth, t.mHeight, 0, GLES20.GL_RGBA,
                GLES20.GL_UNSIGNED_BYTE, t.mData);
        }
        
        shaderProgramID = SampleUtils.createProgramFromShaderSrc(
            CubeShaders.CUBE_MESH_VERTEX_SHADER,
            CubeShaders.CUBE_MESH_FRAGMENT_SHADER);
        vertexHandle = GLES20.glGetAttribLocation(shaderProgramID,
            "vertexPosition");
        textureCoordHandle = GLES20.glGetAttribLocation(shaderProgramID,
            "vertexTexCoord");
        mvpMatrixHandle = GLES20.glGetUniformLocation(shaderProgramID,
            "modelViewProjectionMatrix");
        
        vbShaderProgramOcclusionID = SampleUtils.createProgramFromShaderSrc(
            PassThroughShaders.PASS_THROUGH_VERTEX_SHADER,
            OcclusionShaders.OCCLUSION_FRAGMENT_SHADER);
        vbVertexPositionOcclusionHandle = GLES20.glGetAttribLocation(
            vbShaderProgramOcclusionID, "vertexPosition");
        vbVertexTexCoordOcclusionHandle = GLES20.glGetAttribLocation(
            vbShaderProgramOcclusionID, "vertexTexCoord");
        vbProjectionMatrixOcclusionHandle = GLES20.glGetUniformLocation(
            vbShaderProgramOcclusionID, "modelViewProjectionMatrix");
        vbViewportOriginHandle = GLES20.glGetUniformLocation(
            vbShaderProgramOcclusionID, "viewportOrigin");
        vbViewportSizeHandle = GLES20.glGetUniformLocation(
            vbShaderProgramOcclusionID, "viewportSize");
        vbTextureRatioHandle = GLES20.glGetUniformLocation(
            vbShaderProgramOcclusionID, "textureRatio");
        vbTexSamplerVideoOcclusionHandle = GLES20.glGetUniformLocation(
            vbShaderProgramOcclusionID, "texSamplerVideo");
        vbTexSamplerMaskOcclusionHandle = GLES20.glGetUniformLocation(
            vbShaderProgramOcclusionID, "texSamplerMask");

        vbOrthoQuadVertices = fillBuffer(vbOrthoQuadVerticesArray);
        vbOrthoQuadTexCoords = fillBuffer(vbOrthoQuadTexCoordsArray);
        vbOrthoQuadIndices = fillBuffer(vbOrthoQuadIndicesArray);
        
        setViewport();
    }
    
    
    public void setViewport()
    {
        VideoBackgroundConfig config = Renderer.getInstance()
            .getVideoBackgroundConfig();
        
        DisplayMetrics metrics = new DisplayMetrics();
        mActivity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        
        viewportPosition_x = (((int) (metrics.widthPixels - config.getSize()
            .getData()[0])) / (int) 2) + config.getPosition().getData()[0];
        viewportPosition_y = (((int) (metrics.heightPixels - config.getSize()
            .getData()[1])) / (int) 2) + config.getPosition().getData()[1];
        viewportSize_x = config.getSize().getData()[0];
        viewportSize_y = config.getSize().getData()[1];
        Log.e(LOGTAG, "x: " + viewportPosition_x + ", y: " + viewportPosition_y
            + ", Size x: " + viewportSize_x + ", Size y: " + viewportSize_y);
    }
    
    
    private Buffer fillBuffer(double[] array)
    {
        // Convert to floats because OpenGL doesn't work on doubles, and
        // manually casting each input value would take too much time.
        // each float takes 4 bytes
        ByteBuffer bb = ByteBuffer.allocateDirect(4 * array.length);
        bb.order(ByteOrder.LITTLE_ENDIAN);
        for (double d : array)
            bb.putFloat((float) d);
        bb.rewind();
        
        return bb;
        
    }
    
    
    private Buffer fillBuffer(short[] array)
    {
        ByteBuffer bb = ByteBuffer.allocateDirect(2 * array.length); // each
                                                                     // short
                                                                     // takes 2
                                                                     // bytes
        bb.order(ByteOrder.LITTLE_ENDIAN);
        for (short s : array)
            bb.putShort(s);
        bb.rewind();
        
        return bb;
        
    }


    // The render function called from SampleAppRendering by using RenderingPrimitives views.
    // The state is owned by SampleAppRenderer which is controlling it's lifecycle.
    // State should not be cached outside this method.
    public void renderFrame(State state, float[] projectionMatrix, int[] viewport)
    {
        SampleUtils.checkGLError("Check gl errors prior render Frame");
        
        // Clear color and depth buffer
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        
        vbOrthoQuadTexCoords = fillBuffer(vbOrthoQuadTexCoordsArray);
        
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_CULL_FACE);

        mSampleAppRenderer.renderVideoBackground();
        SampleUtils.checkGLError("Rendering of the video background");

        //
        // //////////////////////////////////////////////////////////////////////////
        
        // //////////////////////////////////////////////////////////////////////////
        // These OpenGL setup calls are important for a proper blending
        //
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        //
        // //////////////////////////////////////////////////////////////////////////
        
        // Did we find any trackables this frame?
        if (state.getNumTrackableResults() > 0)
        {
            // Get the trackable:
            TrackableResult result = null;
            int numResults = state.getNumTrackableResults();
            
            // Browse results searching for the MultiTarget
            for (int j = 0; j < numResults; j++)
            {
                result = state.getTrackableResult(j);
                if (result.isOfType(MultiTargetResult.getClassType()))
                    break;
                result = null;
            }
            
            // If it was not found exit
            if (result == null)
            {
                // Clean up and leave
                GLES20.glDisable(GLES20.GL_BLEND);
                GLES20.glDisable(GLES20.GL_DEPTH_TEST);
                
                return;
            }
            
            Matrix44F modelViewMatrix_Vuforia = Tool
                .convertPose2GLMatrix(result.getPose());
            float modelViewMatrix[] = modelViewMatrix_Vuforia.getData();
            float[] modelViewProjectionCube = new float[16];
            float[] modelViewProjectionTeapot = new float[16];
            
            Matrix.scaleM(modelViewMatrix, 0, kCubeScaleX, kCubeScaleY,
                kCubeScaleZ);
            Matrix.multiplyMM(modelViewProjectionCube, 0, projectionMatrix, 0, modelViewMatrix, 0);
            
            // //////////////////////////////////////////////////////////////////////
            // First, we render the faces that serve as a "background" to the
            // teapot
            // with a checkerboard texture. This helps the user to have a
            // visually
            // constrained space (otherwise the teapot looks floating in space)
            //
            GLES20.glEnable(GLES20.GL_CULL_FACE);
            GLES20.glCullFace(GLES20.GL_FRONT);

            GLES20.glUseProgram(shaderProgramID);
            GLES20.glVertexAttribPointer(vertexHandle, 3, GLES20.GL_FLOAT,
                false, 0, cubeObject.getVertices());
            GLES20.glVertexAttribPointer(textureCoordHandle, 2,
                GLES20.GL_FLOAT, false, 0, cubeObject.getTexCoords());
            GLES20.glEnableVertexAttribArray(vertexHandle);
            GLES20.glEnableVertexAttribArray(textureCoordHandle);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,
                mTextures.get(0).mTextureID[0]);
            GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false,
                modelViewProjectionCube, 0);
            GLES20.glDrawElements(GLES20.GL_TRIANGLES,
                cubeObject.getNumObjectIndex(), GLES20.GL_UNSIGNED_SHORT,
                cubeObject.getIndices());
            
            GLES20.glCullFace(GLES20.GL_BACK);
            
            SampleUtils.checkGLError("Back faces of the box");
            //
            // //////////////////////////////////////////////////////////////////////
            
            // //////////////////////////////////////////////////////////////////////
            // Then, we render the actual teapot
            //
            modelViewMatrix = modelViewMatrix_Vuforia.getData();
            Matrix.translateM(modelViewMatrix, 0, 0.0f * 0.12f,
                -0.0f * 0.12f, -0.17f * 0.12f);
            Matrix.rotateM(modelViewMatrix, 0, 90.0f, 0.0f, 0, 1);
            Matrix.scaleM(modelViewMatrix, 0, kTeapotScaleX, kTeapotScaleY,
                kTeapotScaleZ);
            Matrix.multiplyMM(modelViewProjectionTeapot, 0, projectionMatrix, 0, modelViewMatrix, 0);
            GLES20.glUseProgram(shaderProgramID);
            GLES20.glEnableVertexAttribArray(vertexHandle);
            GLES20.glEnableVertexAttribArray(textureCoordHandle);
            GLES20.glVertexAttribPointer(vertexHandle, 3, GLES20.GL_FLOAT,
                false, 0, teapot.getVertices());
            GLES20.glVertexAttribPointer(textureCoordHandle, 2,
                GLES20.GL_FLOAT, false, 0, teapot.getTexCoords());
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,
                mTextures.get(1).mTextureID[0]);
            GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false,
                modelViewProjectionTeapot, 0);
            GLES20.glDrawElements(GLES20.GL_TRIANGLES,
                teapot.getNumObjectIndex(), GLES20.GL_UNSIGNED_SHORT,
                teapot.getIndices());
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
            //
            // //////////////////////////////////////////////////////////////////////
            
            // //////////////////////////////////////////////////////////////////////
            // Finally, we render the top layer based on the video image
            // this is the layer that actually gives the "transparent look"
            // notice that we use the mask.png (textures[2]->mTextureID)
            // to define how the transparency looks, you can play around with
            // that
            // texture to change the effects.
            //
            VideoBackgroundTextureInfo texInfo = Renderer.getInstance()
                    .getVideoBackgroundTextureInfo();
            int tempImgSize[] = texInfo.getImageSize().getData();
            int tempTexSize[] = texInfo.getTextureSize().getData();

            float uRatio = (tempImgSize[0] / (float) tempTexSize[0]);
            float vRatio = (tempImgSize[1] / (float) tempTexSize[1]);


            int vbVideoTextureUnit = mSampleAppRenderer.getVideoTextureId();
            int vbMaskTextureUnit = 1;
            if(vbVideoTextureUnit > -1)
            {
                GLES20.glDepthFunc(GLES20.GL_LEQUAL);
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + vbMaskTextureUnit);
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,
                        mTextures.get(2).mTextureID[0]);
                GLES20.glEnable(GLES20.GL_BLEND);
                GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,
                        GLES20.GL_ONE_MINUS_SRC_ALPHA);

                GLES20.glDisable(GLES20.GL_DEPTH_TEST);
                GLES20.glUseProgram(vbShaderProgramOcclusionID);
                GLES20.glVertexAttribPointer(vbVertexPositionOcclusionHandle, 3,
                        GLES20.GL_FLOAT, false, 0, cubeObject.getVertices());
                GLES20.glVertexAttribPointer(vbVertexTexCoordOcclusionHandle, 2,
                        GLES20.GL_FLOAT, false, 0, cubeObject.getTexCoords());
                GLES20.glEnableVertexAttribArray(vbVertexPositionOcclusionHandle);
                GLES20.glEnableVertexAttribArray(vbVertexTexCoordOcclusionHandle);

                GLES20.glUniform2f(vbViewportOriginHandle, viewport[0],
                        viewport[1]);
                GLES20.glUniform2f(vbViewportSizeHandle, viewport[2],
                        viewport[3]);
                GLES20.glUniform2f(vbTextureRatioHandle, uRatio, vRatio);
                GLES20.glUniform1i(vbTexSamplerVideoOcclusionHandle,
                        vbVideoTextureUnit);
                GLES20.glUniform1i(vbTexSamplerMaskOcclusionHandle,
                        vbMaskTextureUnit);
                GLES20.glUniformMatrix4fv(vbProjectionMatrixOcclusionHandle, 1,
                        false, modelViewProjectionCube, 0);
                GLES20.glDrawElements(GLES20.GL_TRIANGLES,
                        cubeObject.getNumObjectIndex(), GLES20.GL_UNSIGNED_SHORT,
                        cubeObject.getIndices());
                GLES20.glDisableVertexAttribArray(vbVertexPositionOcclusionHandle);
                GLES20.glDisableVertexAttribArray(vbVertexTexCoordOcclusionHandle);
                GLES20.glUseProgram(0);

                GLES20.glDisableVertexAttribArray(vertexHandle);
                GLES20.glDisableVertexAttribArray(textureCoordHandle);

                GLES20.glDepthFunc(GLES20.GL_LESS);
            }

            SampleUtils.checkGLError("Transparency layer");
            //
            // //////////////////////////////////////////////////////////////////////
        }
        
        GLES20.glDisable(GLES20.GL_BLEND);
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        
        Renderer.getInstance().end();
        
    }
    
    
    public void setTextures(Vector<Texture> textures)
    {
        mTextures = textures;
        
    }
    
}
